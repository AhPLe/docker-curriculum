files for PA2 project
note: the priveleges for file test.sh MUST be modified before building
use command in ubuntu terminal: "chmod +x test.sh"

